<?php

/**
 * Sh.php
 *
 * This file creates a Bourne shell wrapper from the Shell class.
 *
 * @author John P. Bloch <john@avendimedia.com>
 * @version @@PACKAGE_VERSION@@
 * @license http://www.gnu.org/copyleft/gpl.html GPLv3 or later
 */
namespace PHP_Shell;

class Sh extends Shell
{

}
